<?php
include 'connect.php';
$id=$_GET['updateid'];
$sql="SELECT * FROM crd1 WHERE id=$id";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);

$name=$row['name'];
$email=$row['email'];
$mobile=$row['mobile'];
$password=$row['password'];




if (isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];
    $password=$_POST ['password'];

    $sql="UPDATE crd1 set id=$id, name='$name', email='$email', mobile='$mobile', password='$password' WHERE id=$id  ";
    $result=mysqli_query($con,$sql);
    if($result){
        //  echo "update success";
         header('location: display.php');
    }else{
        die (mysqli_error($con));
    }
}
?> 


<!doctype html>
<html lang="en">
  <head>
   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">

    <title>crud !</title>
  </head>
  <body style="background-color: aquamarine;">
  <div class="container my-5">
  <form method="POST">

  <div class="mb-3">
  <div class="form-group">   
  <label class="form-label">Name</label>
    <input type="text" class="form-control " placeholder="enter your name" name="name" autocomplete="off"  value=<?php echo $name;?> required>
  </div>
  <div class="form-group">
    <label class="form-label">Email</label>
    <input type="email" class="form-control " placeholder="enter your email" name="email" autocomplete="off"  value=<?php echo $email;?> required>
  </div>
  <div class="form-group">
  <label class="form-label">Mobile</label>
    <input type="text" class="form-control " placeholder="enter mobile num" name="mobile" autocomplete="off"  value=<?php echo $mobile;?> required>
  </div>

  <div class="form-group">
    <label class="form-label">password</label>
    <input type="password" class="form-control " placeholder="enter your password" name="password" autocomplete="off"  value=<?php echo $password;?> required>
  </div>
  
  <button type="submit" class="btn btn-info my-3" name="submit">Update</button>
</form>
  </div>
 

   
  </body>
</html>
<?php

$con=new mysqli('localhost', 'root', '', 'crudopr');
if (!$con){
   
    die (mysqli_error($con));
}
    
?>